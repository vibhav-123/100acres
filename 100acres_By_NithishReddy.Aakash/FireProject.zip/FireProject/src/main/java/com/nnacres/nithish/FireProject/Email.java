package com.nnacres.nithish.FireProject;

public class Email {
	private String email;
	private int id;
public Email()
{
}
public Email(String email)
{
	this.email=email;
}
public void setemail(String email)
{
	this.email=email;
}
public String getemail()
{
	return email;
}
public void setid(int id)
{
	this.id=id;
}
public int getid()
{
	return id;
}
}
