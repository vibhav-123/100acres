<?php
class Users extends MX_Controller {
 
	public function index()
	{
		$this->load->view('users_view');
	}
}
?>
