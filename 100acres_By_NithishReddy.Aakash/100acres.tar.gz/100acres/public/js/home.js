function klikaj(i,j,k)
{
    document.getElementById(i).style.display='block';
    document.getElementById(j).style.display='none';
    document.getElementById(k).style.display='block';
}


  
