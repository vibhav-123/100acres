function myFunction() {
	var x=document.getElementsById("uname").value;
    if (x == '') {
        alert("Field is empty");
    }
}
