window.onload=function()
{
	document.getElementById("form1").onsubmit= function() 
	{
		 
			
		if(document.getElementById("TypeId").value == 0)
		 { 
			
			/*window.location.replace("http://www.100acres.com/frontend_dev.php/register/index");*/ 
			//history.back();
			document.getElementById("TypeId").focus();
			 return false;
		 } 

		 if(document.getElementById("city").value == 0)
		 { 
			
			/*window.location.replace("http://www.100acres.com/frontend_dev.php/register/index");*/ 
			//history.back();
			document.getElementById("city").focus();
			 return false;
		 } 
		
		 if(document.getElementById("fileToUpload").value == '')
		 { 
			
			/*window.location.replace("http://www.100acres.com/frontend_dev.php/register/index");*/ 
			//history.back();
			document.getElementById("fileToUpload").focus();
			 return false;
		 } 
		 if(document.getElementById("bedroom").value == 0)
		 { 
			
			/*window.location.replace("http://www.100acres.com/frontend_dev.php/register/index");*/ 
			//history.back();
			document.getElementById("bedroom").focus();
			 return false;
		 } 

		 

		 if(document.getElementById("cr").value == 100)
		 { 
			
			/*window.location.replace("http://www.100acres.com/frontend_dev.php/register/index");*/ 
			//history.back();
			document.getElementById("cr").focus();
			 return false;
		 }
		 if(document.getElementById("la").value == 100)
		 { 
			
			/*window.location.replace("http://www.100acres.com/frontend_dev.php/register/index");*/ 
			//history.back();
			document.getElementById("la").focus();
			 return false;
		 }

		  if(document.getElementById("th").value == 100)
		 { 
			
			/*window.location.replace("http://www.100acres.com/frontend_dev.php/register/index");*/ 
			//history.back();
			document.getElementById("th").focus();
			 return false;
		 }
	}
}
